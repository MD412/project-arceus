# Pokemon Card Detection > 2025-06-11 11:18pm
https://universe.roboflow.com/gridcap/pokemon-card-detection-kcqtb

Provided by a Roboflow user
License: CC BY 4.0

